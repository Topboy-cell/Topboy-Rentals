
document.getElementById('adminForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    // Simple username and password check
    if (username === 'admin' && password === 'admin123') {
        document.getElementById('adminMessage').innerText = 'Login successful! Welcome to the admin panel.';
    } else {
        document.getElementById('adminMessage').innerText = 'Incorrect username or password. Please try again.';
    }
});